from flask import Flask, render_template, request, redirect, url_for, session
import json
import os
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'cattle_app_secret_key_2024'

DATA_FILE = 'cattle_treatments.json'


# -------------------------
# DATA HELPERS
# -------------------------

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    return {}


def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)


def get_medications():
    """Return the global medications list, seeding LA-200 if not present."""
    data = load_data()
    if 'medications' not in data:
        data['medications'] = [
            {
                "id": 1,
                "name": "LA-200",
                "note": "Oxytetracycline — broad-spectrum antibiotic",
                "has_calc": "weight_based",
                "dose_ml": 4.5,
                "dose_per_lbs": 100,
                "built_in": True
            }
        ]
        save_data(data)

    # Migrate legacy entries missing dose_ml / dose_per_lbs
    changed = False
    for med in data['medications']:
        # Old 'la200' has_calc → unified 'weight_based'
        if med.get('has_calc') == 'la200':
            med['has_calc']     = 'weight_based'
            med.setdefault('dose_ml', 4.5)
            med.setdefault('dose_per_lbs', 100)
            changed = True
        # weight_based entry missing the ratio fields
        if med.get('has_calc') == 'weight_based' and 'dose_ml' not in med:
            if med.get('name') == 'LA-200':
                med['dose_ml']      = 4.5
                med['dose_per_lbs'] = 100
            else:
                med['has_calc'] = 'none'   # can't guess — fall back to manual
            changed = True
    if changed:
        save_data(data)

    return data['medications']


def save_treatment(herd, tag_number, medicine, notes):
    data = load_data()
    if herd not in data:
        data[herd] = []
    new_treatment = {
        "id": max((t["id"] for t in data[herd]), default=0) + 1,
        "tag_number": tag_number,
        "medicine": medicine,
        "notes": notes,
        "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    data[herd].append(new_treatment)
    save_data(data)


def update_treatment(herd, treatment_id, tag_number, medicine, notes):
    data = load_data()
    for t in data.get(herd, []):
        if t["id"] == treatment_id:
            t["tag_number"] = tag_number
            t["medicine"] = medicine
            t["notes"] = notes
            t["last_updated"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    save_data(data)


# -------------------------
# ROUTES
# -------------------------

@app.route("/dashboard")
def dashboard():
    if "herd" not in session:
        return redirect(url_for("select_herd"))

    data = load_data()
    herd = session["herd"]
    treatments = data.get(herd, [])

    one_week_ago = datetime.now() - timedelta(days=7)
    treated_this_week = sum(
        1 for t in treatments
        if datetime.strptime(t["timestamp"], "%Y-%m-%d %H:%M:%S") >= one_week_ago
    )
    unique_animals = len(set(t["tag_number"] for t in treatments))

    if treatments:
        last_ts = sorted(treatments, key=lambda x: x["timestamp"])[-1]["timestamp"]
        last_treatment_date = last_ts[:10]
    else:
        last_treatment_date = "None"

    all_meds = []
    for t in treatments:
        for med in t.get("medicine", "").split(","):
            name = med.strip().split(" ")[0]
            if name and name not in all_meds:
                all_meds.append(name)
    medicines_used = ", ".join(all_meds[:6])

    return render_template(
        "dashboard.html",
        herd=herd,
        treated_this_week=treated_this_week,
        total_treatments=len(treatments),
        unique_animals=unique_animals,
        last_treatment_date=last_treatment_date,
        medicines_used=medicines_used
    )


@app.route('/select-herd', methods=['GET', 'POST'])
def select_herd():
    data = load_data()
    herds = [k for k in data.keys() if not k.endswith('_costs') and k != 'medications']

    if request.method == 'POST':
        existing = request.form.get('existing_herd', '').strip()
        new = request.form.get('new_herd', '').strip()
        herd = new if new else existing
        if herd:
            session.clear()
            session['herd'] = herd
            data = load_data()
            if herd not in data:
                data[herd] = []
                save_data(data)
            return redirect(url_for('dashboard'))

    return render_template('select_herd.html', herds=herds)


@app.route('/')
def home():
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    return redirect(url_for('dashboard'))


@app.route('/records')
def index():
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    data = load_data()
    herd = session['herd']
    treatments = data.get(herd, [])
    return render_template('index.html', herd=herd, treatments=treatments)


@app.route('/step1')
def step1():
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    if 'medicines' in session:
        session.pop('medicines')
    return render_template('step1_tag.html', herd=session['herd'])


@app.route('/step2', methods=['POST'])
def step2():
    tag_number = request.form.get('tag_number', '').strip()
    if not tag_number:
        return redirect(url_for('step1'))
    session['tag_number'] = tag_number
    medications = get_medications()
    return render_template(
        'step2_medicine.html',
        tag_number=tag_number,
        herd=session['herd'],
        medications=medications
    )


@app.route('/step3', methods=['POST'])
def step3():
    medicine_type = request.form.get('medicine_type', '').strip()
    add_another   = request.form.get('add_another', '')

    if medicine_type == 'weight_based':
        medicine = request.form.get('weight_dosage', '').strip()
    elif medicine_type:
        manual = request.form.get('manual_dose', '').strip()
        medicine = f"{medicine_type} {manual}".strip() if manual else medicine_type
    else:
        return redirect(url_for('step1'))

    if not medicine:
        return redirect(url_for('step2'))

    if 'medicines' not in session:
        session['medicines'] = []
    session['medicines'].append(medicine)
    session.modified = True

    medications = get_medications()

    if add_another == 'yes':
        return render_template(
            'step2_medicine.html',
            tag_number=session['tag_number'],
            herd=session['herd'],
            medications=medications
        )
    else:
        session['medicine'] = ', '.join(session['medicines'])
        return render_template(
            'step3_notes.html',
            herd=session['herd'],
            tag_number=session['tag_number'],
            medicine=session['medicine']
        )


@app.route('/summary', methods=['POST'])
def summary():
    notes = request.form.get('notes', '').strip()
    herd  = session['herd']

    if 'edit_id' in session:
        update_treatment(herd, session['edit_id'], session['tag_number'], session['medicine'], notes)
        session.pop('edit_id')
    else:
        save_treatment(herd, session['tag_number'], session['medicine'], notes)

    if 'medicines' in session:
        session.pop('medicines')
    return redirect(url_for('index'))


@app.route('/edit/<int:treatment_id>')
def edit(treatment_id):
    herd = session.get('herd')
    data = load_data()
    treatment = next((t for t in data.get(herd, []) if t["id"] == treatment_id), None)
    if not treatment:
        return redirect(url_for('index'))
    session['edit_id']    = treatment_id
    session['tag_number'] = treatment['tag_number']
    session['medicine']   = treatment['medicine']
    return render_template('step1_tag.html', herd=herd, tag_number=treatment['tag_number'], is_edit=True)


@app.route('/delete/<int:treatment_id>', methods=['POST'])
def delete(treatment_id):
    herd = session.get('herd')
    data = load_data()
    data[herd] = [t for t in data.get(herd, []) if t["id"] != treatment_id]
    save_data(data)
    return redirect(url_for('index'))


# -------------------------
# COST ROUTES
# -------------------------

@app.route('/cost')
def cost():
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    data  = load_data()
    herd  = session['herd']
    costs = data.get(herd + '_costs', [])
    total_cost = sum(c['cost'] for c in costs)
    return render_template('cost.html', herd=herd, costs=costs, total_cost=total_cost)


@app.route('/cost/add', methods=['POST'])
def add_cost():
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    tag_number = request.form.get('tag_number', '').strip()
    cost_val   = request.form.get('cost', '').strip()
    if not tag_number or not cost_val:
        return redirect(url_for('cost'))
    try:
        cost_float = float(cost_val)
        if cost_float < 0:
            return redirect(url_for('cost'))
    except ValueError:
        return redirect(url_for('cost'))

    data = load_data()
    herd = session['herd']
    key  = herd + '_costs'
    if key not in data:
        data[key] = []
    data[key].append({
        "id": max((c["id"] for c in data[key]), default=0) + 1,
        "tag_number": tag_number,
        "cost": cost_float,
        "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })
    save_data(data)
    return redirect(url_for('cost'))


@app.route('/cost/delete/<int:cost_id>', methods=['POST'])
def delete_cost(cost_id):
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    data = load_data()
    herd = session['herd']
    key  = herd + '_costs'
    data[key] = [c for c in data.get(key, []) if c['id'] != cost_id]
    save_data(data)
    return redirect(url_for('cost'))


# -------------------------
# MEDICAL SUPPLY ROUTES
# -------------------------

@app.route('/supply')
def supply():
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    medications = get_medications()
    return render_template('medical_supply.html', medications=medications)


@app.route('/supply/add', methods=['POST'])
def supply_add():
    if 'herd' not in session:
        return redirect(url_for('select_herd'))

    med_name    = request.form.get('med_name', '').strip()
    med_note    = request.form.get('med_note', '').strip()
    has_calc    = request.form.get('has_calc', 'none').strip()
    dose_ml_str = request.form.get('dose_ml', '').strip()
    dose_lbs_str= request.form.get('dose_per_lbs', '').strip()

    if not med_name:
        return redirect(url_for('supply'))

    data = load_data()
    if 'medications' not in data:
        get_medications()
        data = load_data()

    # Prevent duplicates (case-insensitive)
    existing_names = [m['name'].lower() for m in data['medications']]
    if med_name.lower() in existing_names:
        return redirect(url_for('supply'))

    new_med = {
        "id":       max((m["id"] for m in data["medications"]), default=0) + 1,
        "name":     med_name,
        "note":     med_note,
        "has_calc": has_calc,
        "built_in": False
    }

    # Store dosage ratio if weight-based
    if has_calc == 'weight_based' and dose_ml_str and dose_lbs_str:
        try:
            new_med["dose_ml"]      = float(dose_ml_str)
            new_med["dose_per_lbs"] = float(dose_lbs_str)
        except ValueError:
            new_med["has_calc"] = "none"

    data['medications'].append(new_med)
    save_data(data)
    return redirect(url_for('supply'))


@app.route('/supply/delete/<int:med_id>', methods=['POST'])
def supply_delete(med_id):
    if 'herd' not in session:
        return redirect(url_for('select_herd'))
    data = load_data()
    if 'medications' in data:
        data['medications'] = [
            m for m in data['medications']
            if not (m['id'] == med_id and not m.get('built_in', False))
        ]
        save_data(data)
    return redirect(url_for('supply'))


@app.route('/supply/edit/<int:med_id>', methods=['POST'])
def supply_edit(med_id):
    if 'herd' not in session:
        return redirect(url_for('select_herd'))

    med_name     = request.form.get('med_name', '').strip()
    med_note     = request.form.get('med_note', '').strip()
    has_calc     = request.form.get('has_calc', 'none').strip()
    dose_ml_str  = request.form.get('dose_ml', '').strip()
    dose_lbs_str = request.form.get('dose_per_lbs', '').strip()

    if not med_name:
        return redirect(url_for('supply'))

    data = load_data()
    if 'medications' not in data:
        return redirect(url_for('supply'))

    for med in data['medications']:
        if med['id'] == med_id:
            med['name']     = med_name
            med['note']     = med_note
            med['has_calc'] = has_calc
            # Clear old ratio fields
            med.pop('dose_ml', None)
            med.pop('dose_per_lbs', None)
            # Store new ratio if weight-based and values provided
            if has_calc == 'weight_based' and dose_ml_str and dose_lbs_str:
                try:
                    med['dose_ml']      = float(dose_ml_str)
                    med['dose_per_lbs'] = float(dose_lbs_str)
                except ValueError:
                    med['has_calc'] = 'none'
            break

    save_data(data)
    return redirect(url_for('supply'))


# -------------------------
# HERD MANAGEMENT
# -------------------------

@app.route('/delete-herd/<herd_name>', methods=['POST'])
def delete_herd(herd_name):
    data   = load_data()
    backup = {}
    for key in list(data.keys()):
        if key == herd_name or key == herd_name + '_costs':
            backup[key] = data.pop(key)
    session['deleted_herd_name']   = herd_name
    session['deleted_herd_backup'] = json.dumps(backup)
    save_data(data)
    return render_template('herd_deleted.html', herd_name=herd_name)


@app.route('/undo-delete-herd', methods=['POST'])
def undo_delete_herd():
    backup_json = session.get('deleted_herd_backup')
    if backup_json:
        data   = load_data()
        backup = json.loads(backup_json)
        data.update(backup)
        save_data(data)
        session.pop('deleted_herd_backup', None)
        session.pop('deleted_herd_name', None)
    return redirect(url_for('select_herd'))


# -------------------------
# SWITCH HERD
# -------------------------

@app.route('/switch-herd')
def switch_herd():
    session.clear()
    return redirect(url_for('select_herd'))


if __name__ == '__main__':
    app.run(debug=True, port=5001)
